#!/bin/sh

#   Copyright (C) 2016 Deepin, Inc.
#
#   Author:     Li LongYu <lilongyu@linuxdeepin.com>
#               Peng Hao <penghao@linuxdeepin.com>

BOTTLENAME="Deepin-7zip"
APPVER="15.14deepin2"

/opt/deepinwine/tools/run.sh $BOTTLENAME $APPVER "$1" "$2" "$3"
